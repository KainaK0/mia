from pathlib import Path
import matplotlib.pyplot as plt

def get_data_source(data_type='test', image=''):
    # Ruta del archivo actual
    current_directory = Path(__file__).resolve()

    # Referencia al directorio un nivel previo
    parent_directory = current_directory.parent

    ruta = ''

    # Construye la ruta al archivo o directorio dentro del directorio previo
    if data_type == 'test':
        ruta = parent_directory / 'data/lung-cancer-histopathological-images/test'
    elif data_type == 'train':
        ruta = parent_directory / 'data/lung-cancer-histopathological-images/train'
    elif data_type == 'val':
        ruta = parent_directory / 'data/lung-cancer-histopathological-images/validation' / image

    # print(ruta)

    return ruta

def plot_training_history(num_epochs, train_losses, test_accuracies):
    # Plotting the training loss and test accuracy
    plt.figure(figsize=(12, 5))

    # Plot loss
    plt.subplot(1, 2, 1)
    plt.plot(range(1, num_epochs + 1), train_losses, label='Train Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.title('Training Loss')
    plt.legend()

    # Plot accuracy
    plt.subplot(1, 2, 2)
    plt.plot(range(1, num_epochs + 1), test_accuracies, label='Test Accuracy', color='green')
    plt.xlabel('Epochs')
    plt.ylabel('Accuracy (%)')
    plt.title('Test Accuracy')
    plt.legend()

    plt.show()

