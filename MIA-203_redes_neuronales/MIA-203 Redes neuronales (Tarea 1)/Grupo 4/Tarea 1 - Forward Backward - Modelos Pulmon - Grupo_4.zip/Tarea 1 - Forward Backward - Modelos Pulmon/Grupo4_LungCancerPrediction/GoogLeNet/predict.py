import torch
from PIL import Image
from model import GoogleNet  # Importar el modelo
import torchvision.transforms as transforms
import torch.nn.functional as F  # Para aplicar softmax
import matplotlib.pyplot as plt

# Definir las etiquetas de las clases para el Dataset Lung Cancer (Histopathological Images)
classes = ["adenocarcinoma", "benign", "squamous_cell_carcinoma"]

def predict_image(image_path):
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # Cargar el modelo guardado
    model = GoogleNet(num_classes=3).to(device)
    model.load_state_dict(torch.load('googlenet_lung_cancer_2.pth', weights_only=True))
    model.eval()

    # Cargar y transformar la imagen
    img = Image.open(image_path)
    transform = transforms.Compose([
        transforms.Resize((384, 384)),
        transforms.ToTensor(),
        transforms.Normalize((0.4914, 0.4822, 0.4465), (0.2023, 0.1994, 0.2010))
    ])
    img_tensor = transform(img).unsqueeze(0).to(device)

    # Realizar la predicción
    with torch.no_grad():
        output = model(img_tensor)
        probabilities = F.softmax(output, dim=1)  # Aplicar softmax para obtener probabilidades
        predicted_class_idx = torch.argmax(probabilities, 1).item()  # Obtener el índice de la clase predicha
        predicted_class = classes[predicted_class_idx]  # Nombre de la clase
        probability = probabilities[0, predicted_class_idx].item()  # Probabilidad de la clase predicha

    print(f'Predicted class: {predicted_class}, Probability: {probability:.2f}')

    # Mostrar la imagen y la clase predicha con la probabilidad
    plt.imshow(img)
    plt.title(f'Predicted class: {predicted_class} ({probability*100:.2f}%)')
    plt.axis('off')  # Ocultar los ejes
    plt.show()