from train import train_model
import torch
import predict
from util import get_data_source

def save_model(model, path):
    torch.save(model.state_dict(), path)

def main_train():
    # Train the model
    model = train_model()

    # Save the trained model
    model_path = './googlenet_lung_cancer_4.pth'
    save_model(model, model_path)
    print(f'Model saved to {model_path}')

if __name__ == '__main__':
    # Para entrenar el modelo
    # main_train()

    # Para predecir una nueva imagen
    predict.predict_image(get_data_source('val', 'adenocarcinoma3.png'))
