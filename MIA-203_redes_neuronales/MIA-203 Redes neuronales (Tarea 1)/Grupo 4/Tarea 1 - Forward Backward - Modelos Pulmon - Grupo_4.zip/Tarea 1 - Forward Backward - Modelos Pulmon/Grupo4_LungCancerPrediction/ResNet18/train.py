import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
from torchvision.datasets import ImageFolder
from model import resnet18_model
from util import get_data_source
from util import plot_training_history
from sklearn.metrics import precision_score, recall_score, f1_score, confusion_matrix

def train_model(num_epochs=10, batch_size=64, lr=0.001, device='cuda'):
    # Define transformations for the CIFAR-10 dataset
    transform = transforms.Compose([
        transforms.Resize((384, 384)),  # Resize to 32x32 for CIFAR-10
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))  # Normalize the images
    ])

    # Cargar Dataset Lung Cancer (Histopathological Images)
    train_dataset = datasets.ImageFolder(root=get_data_source('train'), transform=transform)
    test_dataset = datasets.ImageFolder(root=get_data_source('test'), transform=transform)
    train_loader = DataLoader(dataset=train_dataset, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(dataset=test_dataset, batch_size=batch_size, shuffle=False)

    print(f'train dataset size: {len(train_dataset)}')
    print(f'test dataset size: {len(test_dataset)}')
    print(f'train loader: {len(train_loader)}')
    print(f'test loader: {len(test_loader)}')

    # Initialize the model, loss function, and optimizer
    device = torch.device(device if torch.cuda.is_available() else 'cpu')
    model = resnet18_model().to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr)

    # Lists to store loss and accuracy values
    train_losses = []
    test_accuracies = []

    # Training the model
    for epoch in range(num_epochs):
        model.train()  # Set the model to training mode
        running_loss = 0.0
        for batch_idx, data in enumerate(train_loader):
            inputs, labels = data[0].to(device), data[1].to(device)

            # Zero the parameter gradients
            optimizer.zero_grad()

            # Forward pass
            outputs = model(inputs)
            loss = criterion(outputs, labels)

            # Backward pass and optimization
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
            # if batch_idx % 10 == 0:  # Print every 10 batches
            # print(f'Epoch [{epoch + 1}/{num_epochs}], Batch [{batch_idx + 1}/{len(train_loader)}], Loss: {loss.item():.4f}')

        avg_loss = running_loss / len(train_loader)
        train_losses.append(avg_loss)

        print(f'Epoch [{epoch + 1}/{num_epochs}], Loss: {avg_loss:.4f}')

        # Evaluate on test set
        model.eval()  # Set the model to evaluation mode
        correct = 0
        total = 0
        all_preds = []
        all_labels = []
        with torch.no_grad():
            for data in test_loader:
                images, labels = data[0].to(device), data[1].to(device)
                outputs = model(images)
                _, predicted = torch.max(outputs, 1)
                total += labels.size(0)
                correct += (predicted == labels).sum().item()

                # Almacenar todas las predicciones y labels para calcular precision, recall, f1
                all_preds.extend(predicted.cpu().numpy())
                all_labels.extend(labels.cpu().numpy())

        accuracy = 100 * correct / total
        test_accuracies.append(accuracy)
        precision = precision_score(all_labels, all_preds, average='macro')
        recall = recall_score(all_labels, all_preds, average='macro')
        f1 = f1_score(all_labels, all_preds, average='macro')
        cm = confusion_matrix(all_labels, all_preds)

        print(f'Accuracy of the model on the test images: {accuracy:.2f}%')
        print(f'Precision: {precision:.4f}')
        print(f'Recall: {recall:.4f}')
        print(f'F1-Score: {f1:.4f}')
        print(f'Confusion Matrix:\n{cm}')

    plot_training_history(num_epochs, train_losses, test_accuracies)

    return model
