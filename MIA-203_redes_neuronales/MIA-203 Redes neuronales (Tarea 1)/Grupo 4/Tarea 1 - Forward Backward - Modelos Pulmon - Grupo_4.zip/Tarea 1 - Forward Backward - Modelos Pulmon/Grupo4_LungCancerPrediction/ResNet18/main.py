from train import train_model
from predict import predict
import torch
from util import get_data_source


def save_model(model, path):
    torch.save(model.state_dict(), path)

def main_train():
    # Train the model
    model = train_model(num_epochs=10, batch_size=32, lr=0.001, device='cuda')

    # Save the trained model
    model_path = ('./resnet18_lung_cancer.pth')
    save_model(model, model_path)
    print(f'Model saved to {model_path}')

def main_predict():
    # Ruta de la imagen a predecir
    image_path = get_data_source('val', 'adenocarcinoma3.png') # Asegúrate de que la imagen esté en esta ruta

    # Ruta del modelo guardado
    model_path = './resnet18_lung_cancer_2.pth'

    # Realiza la predicción
    predicted_class = predict(image_path, model_path, device='cuda')

    # Imprime la clase predicha
    print(f'Predicted class index: {predicted_class["class_index"]}')
    print(f'Predicted class name: {predicted_class["class_name"]}')
    print(f'Probability of adenocarcinoma: {predicted_class["probability"][0][0]*100:.2f}%')
    print(f'Probability of binign: {predicted_class["probability"][0][1]*100:.2f}%')
    print(f'Probability of squamous_cell_carcinoma: {predicted_class["probability"][0][2]*100:.2f}%')

if __name__ == '__main__':
    # main_train()
    main_predict()
