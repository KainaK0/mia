import torch
from torchvision import transforms
from PIL import Image
from model import resnet18_model
import matplotlib.pyplot as plt

# Definir las etiquetas de las clases de CIFAR-10
# class_names = ['plane', 'car', 'bird', 'cat', 'deer', 'dog', 'frog', 'horse', 'ship', 'truck']

# Definir las etiquetas de las clases para el Dataset Lung Cancer (Histopathological Images)
class_names = ["adenocarcinoma", "benign", "squamous_cell_carcinoma"]

def predict(image_path, model_path, device='cuda'):
    # Define transformations for the input image
    transform = transforms.Compose([
        # Para CIFAR-10 usar:
        # transforms.Resize((32, 32)),
        transforms.Resize((384, 384)),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    # Load the model
    device = torch.device(device if torch.cuda.is_available() else 'cpu')
    model = resnet18_model().to(device)
    model.load_state_dict(torch.load(model_path, map_location=device, weights_only=False))
    model.eval()

    # Load and preprocess the image
    image = Image.open(image_path)
    # Para CIFAR-10 usar:
    # image = transform(image).unsqueeze(0).to(device)
    image_tensor = transform(image).unsqueeze(0).to(device)

    # Predict the class
    with torch.no_grad():
        outputs = model(image_tensor)
        probabilities = torch.nn.functional.softmax(outputs, dim=1)
        _, predicted = torch.max(outputs, 1)

    class_index = predicted.item()
    class_name = class_names[class_index]
    probability = probabilities

    prediction = {'class_index': class_index, 'class_name': class_name, 'probability': probability}

    # Mostrar la imagen y la clase predicha con la probabilidad
    plt.imshow(image)
    plt.title(f'Predicted class index: {class_index}\n'
              f'Predicted class name: {class_name}\n'
              f'Probability of  {class_name}: {probability[0][class_index]*100:.2f}')
    plt.axis('off')  # Ocultar los ejes
    plt.show()

    return prediction
