import os
import shutil
from sklearn.model_selection import train_test_split

# Directorios
base_dir = './dataset-images'
train_dir = './data/lung-cancer-images/train'
test_dir = './data/lung-cancer-images/test'
val_dir = './data/lung-cancer-images/val'

# Clases
categories = ['adenocarcinoma', 'benign', 'squamous_cell_carcinoma']

# Crear carpetas de destino
for category in categories:
    os.makedirs(os.path.join(train_dir, category), exist_ok=True)
    os.makedirs(os.path.join(test_dir, category), exist_ok=True)
    os.makedirs(os.path.join(val_dir, category), exist_ok=True)

# Dividir las imágenes y moverlas
for category in categories:
    class_dir = os.path.join(base_dir, category)
    images = os.listdir(class_dir)

    # Primero dividir en entrenamiento y test+validación
    train_images, temp_images = train_test_split(images, test_size=0.2, random_state=42)

    # Luego dividir temp_images en test y validación
    test_images, val_images = train_test_split(temp_images, test_size=0.05, random_state=42)

    for image in train_images:
        src = os.path.join(class_dir, image)
        dst = os.path.join(train_dir, category, image)
        shutil.move(src, dst)

    for image in test_images:
        src = os.path.join(class_dir, image)
        dst = os.path.join(test_dir, category, image)
        shutil.move(src, dst)

    for image in val_images:
        src = os.path.join(class_dir, image)
        dst = os.path.join(val_dir, category, image)
        shutil.move(src, dst)

print('Imágenes organizadas correctamente.')
