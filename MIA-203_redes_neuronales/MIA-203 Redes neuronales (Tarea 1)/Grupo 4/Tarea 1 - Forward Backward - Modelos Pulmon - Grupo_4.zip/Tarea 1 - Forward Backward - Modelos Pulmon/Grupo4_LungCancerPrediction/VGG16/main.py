from train import train_model
from predict import predict
import torch
from util import get_data_source


def save_model(model, path):
    torch.save(model.state_dict(), path)

def train_main():
    # Train the model
    model = train_model(num_epochs=10, batch_size=64, lr=0.0001, device='cuda')

    # Save the trained model
    model_path = './vgg16_lung_cancer_2.pth'
    save_model(model, model_path)
    print(f'Model saved to {model_path}')

def predict_main():
    # Test predict function
    image_path = get_data_source('val', 'adenocarcinoma3.png')  # Asegúrate de que la imagen esté en esta ruta
    model_path = './vgg16_lung_cancer.pth'
    predicted_class_name, predicted_probability = predict(image_path, model_path, device='cuda')
    print(f'Predicted class: {predicted_class_name} ({predicted_probability*100:.2f}%)')

if __name__ == '__main__':
    # train_main()
    predict_main()
