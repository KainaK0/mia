import torch
from torchvision import transforms
from PIL import Image
from model import VGG16
import matplotlib.pyplot as plt

# Define class names
class_names = [
    "adenocarcinoma", "benign", "squamous_cell_carcinoma"
]

def predict(image_path, model_path, device='cuda'):
    # Define transformations for the input image
    transform = transforms.Compose([
        transforms.Resize((192, 192)),
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))
    ])

    # Load the model
    device = torch.device(device if torch.cuda.is_available() else 'cpu')
    model = VGG16(num_classes=3).to(device)
    model.load_state_dict(torch.load(model_path, map_location=device, weights_only=True))
    model.eval()

    # Load and preprocess the image
    image = Image.open(image_path)
    image_tensor = transform(image).unsqueeze(0).to(device)

    # Predict the class
    with torch.no_grad():
        outputs = model(image_tensor)
        probabilities = torch.nn.functional.softmax(outputs, dim=1)
        _, predicted = torch.max(outputs, 1)

    class_index = predicted.item()
    class_name = class_names[class_index]
    probability = probabilities[0][class_index].item()

    # Mostrar la imagen
    plt.imshow(image)
    plt.title(f'Predicted: {class_name} ({probability*100:.2f}%)')
    plt.axis('off')
    plt.show()

    return class_name, probability
